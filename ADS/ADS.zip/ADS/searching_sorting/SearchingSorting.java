package day8.searching_sorting;

public class SearchingSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

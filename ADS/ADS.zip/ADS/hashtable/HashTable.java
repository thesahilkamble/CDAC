package day11.hashtable;

public interface HashTable {
	
	void insert(int key);
	
	boolean search(int key);

	void display();
	
}

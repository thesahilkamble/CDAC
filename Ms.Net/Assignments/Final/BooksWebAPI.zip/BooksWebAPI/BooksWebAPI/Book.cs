﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BooksMVC.Models
{
    [Table(name:"tbl_books")]
    public class Book
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        [Column(name: "BookID")]
        public int BookID { get; set; }

        [Display(Name ="Book Name")]
        [Required(ErrorMessage ="Book name is required")]
        [DataType("varchar(50)")]
        [StringLength(50, MinimumLength = 5, ErrorMessage ="{0} must in range({2} - {1})")]
        public string BookName { get; set; }

        [Display(Name ="Book Author Name")]
        [Required(ErrorMessage = "Book Author Name is required")]
        [DataType("varchar(50)")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "{0} must in range({2} - {1})")]
        public string BookAuthor { get; set; }

        [Display(Name = "Book Price")]
        [Required(ErrorMessage = "Book Price is required")]
        [DataType("decimal(8,2)")]
        [Range(10, 99999999, ErrorMessage ="{0} must be within range of {1} - {2}")]
        public float BookPrice { get; set; }
    }
}

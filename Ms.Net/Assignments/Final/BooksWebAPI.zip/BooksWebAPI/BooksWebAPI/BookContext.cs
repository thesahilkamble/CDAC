﻿using Microsoft.EntityFrameworkCore;

namespace BooksMVC.Models
{
    public class BookContext : DbContext
    {
        public BookContext() { }

        public BookContext(DbContextOptions<BookContext> options) : base(options) 
        { 
        }

        public virtual DbSet<Book> Books{get; set;}

    }
}

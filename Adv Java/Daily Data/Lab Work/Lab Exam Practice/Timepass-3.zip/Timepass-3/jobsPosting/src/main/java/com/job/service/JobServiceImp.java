package com.job.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.job.entities.Job;
import com.job.repository.JobRepository;

@Service
@Transactional
public class JobServiceImp implements JobService {

	@Autowired
	private JobRepository repository;

@Override
	public List<Job> getAllJobs() {
	return repository.findAll();
	}

@Override
public Optional<Job> getJob(Long id) {

	return repository.findById(id);
}

@Override
public Job addJob(Job job) {
	return repository.save(job);
}

@Override
public String updateJob(Long id, Job job) {
	String onestring = "Not Found";
	if(repository.existsById(id)) {
		onestring = "Found";
		return onestring;		
	}
	return onestring;
}

@Override
public String deleteJob(Long id) {
	String onestring = "Not Found";
	if(repository.existsById(id)) {
		onestring = "Deleted";
		repository.deleteById(id);
		return onestring;		
	}
	return onestring;
}
}


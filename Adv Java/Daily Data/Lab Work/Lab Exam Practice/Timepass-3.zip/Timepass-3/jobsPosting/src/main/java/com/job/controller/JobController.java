package com.job.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.job.entities.Job;
import com.job.service.JobService;

@RestController
@RequestMapping("/jobs")
public class JobController {
	
	@Autowired
	private JobService service;
	
	
@GetMapping
public ResponseEntity<?> getAllJobs(){
	return ResponseEntity.status(HttpStatus.OK).body(service.getAllJobs());
	}
	
	@PostMapping
	public ResponseEntity<?> addJoB(@RequestBody Job job){
		return ResponseEntity.status(HttpStatus.OK).body(service.addJob(job));
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getJob(@PathVariable Long id){
		return ResponseEntity.status(HttpStatus.OK).body(service.getJob(id));
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> updateJob(@PathVariable Long id,@RequestBody Job job){
		return ResponseEntity.status(HttpStatus.OK).body(service.updateJob(id, job));
		
	}
	
	public ResponseEntity<String> deleteJob(@PathVariable Long id)
	{
		return ResponseEntity.status(HttpStatus.OK).body(service.deleteJob(id));
	}

	
}

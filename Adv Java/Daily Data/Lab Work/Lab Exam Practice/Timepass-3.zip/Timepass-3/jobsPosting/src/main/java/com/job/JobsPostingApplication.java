package com.job;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobsPostingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobsPostingApplication.class, args);
	}

}

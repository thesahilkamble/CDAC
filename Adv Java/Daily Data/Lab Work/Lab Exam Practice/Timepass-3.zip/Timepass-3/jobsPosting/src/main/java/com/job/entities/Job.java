package com.job.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "jobs")
public class Job {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(length = 30)
	private String title;
	@Column(length = 30)	
	private String companyName;
	@Column(length = 30)	
	private String location;
	@Column(length = 50)	
	private String description;
	@Column(length = 30)	
	private String requirments;
	private double salary;
	private LocalDate postingDate;
	
}



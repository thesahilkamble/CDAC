package com.job.service;

import java.util.List;
import java.util.Optional;

import com.job.entities.Job;

public interface JobService {

	Job addJob (Job job);
	String updateJob(Long id, Job job);
	String deleteJob(Long id);
	List<Job> getAllJobs();
	Optional<Job> getJob(Long id);

	
	
	
}
